package edu.uabv.fragments;

import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;


import edu.uabv.R;
import edu.uabv.adapter.MyAdapter;
import edu.uabv.model.Item;

import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;

public class ListFragment extends Fragment {
    ListView simpleList;
    TextView nameText, ageText, genderText;
    private long mLastClickTime = 0;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.list_fragment, container, false);
        init(view);
        setPersonalData();
        return view;
    }

    private void setPersonalData() {
        // Retrieving the value using its keys the file name
// must be same in both saving and retrieving the data
        SharedPreferences sh = requireActivity().getSharedPreferences("MySharedPref", MODE_PRIVATE);

// The value will be default as empty string because for
// the very first time when the app is opened, there is nothing to show
        String name = sh.getString("name", "");
        String age = sh.getString("age", "");
        String gender = sh.getString("gender", "");

// We can then use the data
        if (!TextUtils.isEmpty(name)) {
            nameText.setText("Name = " + name);
            ageText.setText("Age = " + age);
            genderText.setText("Gender = " + gender);
        }
    }

    private void init(View pView) {
        simpleList = pView.findViewById(R.id.simpleListView);
        nameText = pView.findViewById(R.id.nameText);
        ageText = pView.findViewById(R.id.ageText);
        genderText = pView.findViewById(R.id.genderText);
        ArrayList<Item> patientinfo  = new ArrayList<>();
        patientinfo.add(new Item("Personal Info", R.drawable.person));
        patientinfo.add(new Item("Medical Condition", R.drawable.medical));
        patientinfo.add(new Item("Symptoms", R.drawable.symptoms));
        MyAdapter myAdapter = new MyAdapter(
                getActivity(), R.layout.list_view_items, patientinfo);
        simpleList.setAdapter(myAdapter);
        simpleList.setOnItemClickListener((parent, view, position, id) -> {
            if (SystemClock.elapsedRealtime() - mLastClickTime < 500) {
                return;
            }
            mLastClickTime = SystemClock.elapsedRealtime();
            replaceFragment(position);
        });

    }

    public void replaceFragment(int position) {
        Fragment fr = null;
        switch (position) {
            case 0: {
                fr = new PersonalInfoFragment();
                break;
            }
//            case 1: {
//                fr = new PersonalInfoFragment();
//                break;
//            }
            case 2: {
                fr = new SymptomsFragment();
                break;
            }
//            default: {
//                fr = new PersonalInfoFragment();
//            }
        }
        if (fr != null) {

            if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
                FragmentManager manager = requireActivity().getSupportFragmentManager();
                FragmentTransaction transaction = manager.beginTransaction();
                transaction.replace(R.id.containerFragment2, fr);
                transaction.commit();
            }
            else
            {
                FragmentManager manager = requireActivity().getSupportFragmentManager();
                FragmentTransaction transaction = manager.beginTransaction();
                transaction.replace(R.id.containerFragment, fr);
                transaction.addToBackStack(null);
                transaction.commit();
            }
        }
    }
}