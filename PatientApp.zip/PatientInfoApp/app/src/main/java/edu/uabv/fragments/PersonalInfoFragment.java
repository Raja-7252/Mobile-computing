package edu.uabv.fragments;

import static android.content.Context.MODE_PRIVATE;

import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import edu.uabv.fragments.ListFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import edu.uabv.R;


public class PersonalInfoFragment extends Fragment {
    EditText nameEdit;
    EditText ageEdit;
    RadioGroup radioGroup;
    RadioButton maleRadio;
    RadioButton femaleRadio;
    Button doneButton;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.info_fragment, container, false);
        init(view);
        return view;
    }

    private void init(View pView) {
        nameEdit = pView.findViewById(R.id.nameEdit);
        ageEdit = pView.findViewById(R.id.ageEdit);
        radioGroup = pView.findViewById(R.id.radio);
        maleRadio = pView.findViewById(R.id.maleRButton);
        femaleRadio = pView.findViewById(R.id.femaleRButton);
        doneButton = pView.findViewById(R.id.btn_done);
        doneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkValidation();
            }
        });
    }

    private void checkValidation() {
        String name = nameEdit.getText().toString();
        String age = ageEdit.getText().toString();
        int genderId = radioGroup.getCheckedRadioButtonId();
        if (TextUtils.isEmpty(name)) {
            Toast.makeText(getActivity(), "Please enter your name", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(age)) {
            Toast.makeText(getActivity(), "Please enter your age", Toast.LENGTH_SHORT).show();
        } else if (genderId == -1) {
            Toast.makeText(getActivity(), "Please select your gender", Toast.LENGTH_SHORT).show();
        } else {
            String gender = "Male";
            if (femaleRadio.isChecked()) {
                gender = "Female";
            }
// Storing data into SharedPreferences
            SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("MySharedPref", MODE_PRIVATE);
// Creating an Editor object to edit(write to the file)
            SharedPreferences.Editor myEdit = sharedPreferences.edit();

// Storing the key and its value as the data fetched from edittext
            myEdit.putString("name", name);
            myEdit.putString("age", age);
            myEdit.putString("gender", gender);
// Once the changes have been made,
// we need to commit to apply those changes made,
// otherwise, it will throw an error
            myEdit.apply();
            if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
                FragmentManager manager = requireActivity().getSupportFragmentManager();
                FragmentTransaction transaction = manager.beginTransaction();
                transaction.replace(R.id.containerFragment, new ListFragment());
                transaction.commit();
            }
            else
            {
                requireActivity().onBackPressed();
            }
        }
    }
}
