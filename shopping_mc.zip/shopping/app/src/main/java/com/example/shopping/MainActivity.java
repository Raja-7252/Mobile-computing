package com.example.shopping;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.stream.Collectors;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> purchased = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView listView = findViewById(R.id.listView);
        ArrayList<String> foodItems = new ArrayList<>();
        foodItems.add("Fruits");
        foodItems.add("Vegetables");
        foodItems.add("Whole Grains");
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,foodItems);
        listView.setAdapter(arrayAdapter);

        ListView listView2 = findViewById(R.id.listView2);
        ArrayList<String> Fruits = new ArrayList<>();
        Fruits.add("Orange");
        Fruits.add("Mango");
        ArrayList<String> Vegetables = new ArrayList<>();
        Vegetables.add("Cauli Flower");
        Vegetables.add("Lady Finger");
        Vegetables.add("Cabbage");
        ArrayList<String> Grains = new ArrayList<>();
        Grains.add("Rice");
        Grains.add("Wheat");
        Grains.add("Barley");

        ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,Fruits);
        ArrayAdapter<String> arrayAdapter3 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,Vegetables);
        ArrayAdapter<String> arrayAdapter4 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,Grains);

        ImageView imageView = findViewById(R.id.imageView);
        ImageView imageView1 = findViewById(R.id.imageView2);
        ImageView imageView2 = findViewById(R.id.imageView3);
        imageView.setVisibility(View.GONE);
        imageView1.setVisibility(View.GONE);
        imageView2.setVisibility(View.GONE);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
              String str = ((TextView)view).getText().toString();
              if(str =="Fruits")
              {
                  listView2.setAdapter(arrayAdapter2);
                  imageView.setVisibility(View.VISIBLE);
                  imageView1.setVisibility(View.GONE);
                  imageView2.setVisibility(View.GONE);
              }
              if(str=="Vegetables")
              {
                  listView2.setAdapter(arrayAdapter3);
                  imageView.setVisibility(View.GONE);
                  imageView1.setVisibility(View.VISIBLE);
                  imageView2.setVisibility(View.GONE);
              }
              if(str=="Whole Grains")
              {
                  listView2.setAdapter(arrayAdapter4);
                  imageView.setVisibility(View.GONE);
                  imageView1.setVisibility(View.GONE);
                  imageView2.setVisibility(View.VISIBLE);
              }
            }
        });

        ListView listView3 = findViewById(R.id.listView3);
        ArrayAdapter<String> arrayAdapter5 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,purchased);
        listView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        String str = ((TextView)view).getText().toString();
                        purchased.add(str);
                        listView3.setAdapter(arrayAdapter5);
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        ListView listView3 = findViewById(R.id.listView3);
        ArrayAdapter<String> arrayAdapter5 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,purchased);
        switch (item.getItemId())
        {
            case R.id.clear:
                purchased.clear();
                listView3.setAdapter(arrayAdapter5);
                break;
            case R.id.load:
                purchased.clear();
                listView3.setAdapter(arrayAdapter5);
                break;
            case R.id.save:
                purchased.clear();
                listView3.setAdapter(arrayAdapter5);
                break;
            case R.id.delete:
                purchased.clear();
                listView3.setAdapter(arrayAdapter5);
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}